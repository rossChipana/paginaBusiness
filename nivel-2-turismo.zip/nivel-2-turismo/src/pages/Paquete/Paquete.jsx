import PaqueteCard from "./PaqueteCard";

const Paquete = () => {
    return(
        <div className="container">
            <div className="row">
                <div className="col">
                    <h2>Paquete</h2>
                    <div className="row">
                        < PaqueteCard/>
                        < PaqueteCard/>
                        < PaqueteCard/>
                        < PaqueteCard/>
                        < PaqueteCard/>
                    </div>
                </div>
            </div>
        </div>
    );
};
export default Paquete;
