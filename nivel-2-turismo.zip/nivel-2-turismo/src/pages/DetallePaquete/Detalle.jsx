const Detalle = () => {
    return(
        <>
            <h1>DETALLE</h1>
            <p> El tour operador o el operador turístico tiene
             la obligación de trasladar al pasajero a un lugar 
             de vacaciones determinado, porque allí se concertará
            el servicio de transporte, y allí se contratará el 
              hotel. Por ello, si un usuario dice que le interesa
               visitar un país, hay que dejar claro qué área de este
                país le puede interesar y, a continuación, hacerle 
                elegir un centro de interés turístico concreto. 
                Debemos recordar, no obstante, el hecho de que 
                incluso en una misma ciudad, existen varios centros 
                turísticos, ya que quedarse en el área urbana, en el
                 parque o en los alrededores, es una de las posibilidades 
                 de recreación que no se dan en ningún otro lugar. </p>   
                 </>               
    );
};
export default Detalle;
