const Itinerario = () => {
    return(
        <table>
            <thead>
                <tr>
                    <th>Hora</th>
                    <th>Dia</th>
                    <th>Actividad</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>06:00 am</td>
                    <td>Martes</td>
                    <td>Desayuno</td>
                </tr>
                <tr>
                    <td>08:00 am</td>
                    <td>Martes</td>
                    <td>Inicio paseo Bosque</td>
                </tr>
            </tbody>
        </table>    
        
    );
};
export default Itinerario;
