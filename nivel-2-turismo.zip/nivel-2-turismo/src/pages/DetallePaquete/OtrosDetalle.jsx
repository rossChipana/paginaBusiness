const OtrosDetalle = () => {
    return(<>
        <h1>Lista</h1>
        <div className="row">
            <div className="col-md-6">
                <div className="card">
                    <div className="card-body">
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="alojamiento" />
                            <label className="form-check-label" htmlFor="alojamiento">
                                <span>&#10003;</span> Alojamiento
                            </label>
                        </div>
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="renta-autos" />
                            <label className="form-check-label" htmlFor="renta-autos">
                                <span>&#10003;</span> Renta de Autos
                            </label>
                        </div>
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="renta-autobuses" />
                            <label className="form-check-label" htmlFor="renta-autobuses">
                                <span>&#10003;</span> Renta de autobuses
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-6">
                <div className="card">
                    <div className="card-body">
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="circuito-turistico" />
                            <label className="form-check-label" htmlFor="circuito-turistico">
                                <span>&#10003;</span> Circuito Turistico
                            </label>
                        </div>
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="excursiones" />
                            <label className="form-check-label" htmlFor="excursiones">
                                <span>&#10003;</span> Excursiones
                            </label>
                        </div>
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="planificador-bodas" />
                            <label className="form-check-label" htmlFor="planificador-bodas">
                                <span>&#10003;</span> Planificador de bodas
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>    );
};
export default OtrosDetalle;
