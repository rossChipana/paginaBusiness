const OtrosDetallesDos = () => {
    return(
        <>
        
        <div>
            <h1>Lista</h1>
            <div className="row">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-body">
                            <div className="form-check">
                                <label className="form-check-label">
                                    <span>1.</span> Alojamiento
                                </label>
                            </div>
                            <div className="form-check">
                                <label className="form-check-label">
                                    <span>2.</span> Renta de Autos
                                </label>
                            </div>
                            <div className="form-check">
                                <label className="form-check-label">
                                    <span>3.</span> Renta de autobuses
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-body">
                            <div className="form-check">
                                <label className="form-check-label">
                                    <span>4.</span> Circuito Turistico
                                </label>
                            </div>
                            <div className="form-check">
                                <label className="form-check-label">
                                    <span>5.</span> Excursiones
                                </label>
                            </div>
                            <div className="form-check">
                                <label className="form-check-label">
                                    <span>6.</span> Planificador de bodas
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>
                  
    );
};
export default OtrosDetallesDos;
