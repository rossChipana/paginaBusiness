const PaqueteMR = () => {
    return(
        <>
        <img src="./src/assets/images/}comida.png" className="rounded float-start" alt="izquierda"style={{ width: '300px' }}></img>
        <img src="./src/assets/images/rio.png" className="rounded mx-auto d-block" alt="centro" style={{ width: '300px' }}>
 </img>
    <img src="./src/assets/images/cuarto.png" className="rounded float-end" alt="derecha"style={{ width: '300px' }}></img>

    
        </>

    );
};
export default PaqueteMR;
