import PaqueteMR from "./PaqueteMR";
import Detalle from "./Detalle";
import Itinerario from "./Itinerario";
import OtrosDetalle from "./OtrosDetalle";
import OtrosDetallesDos from "./OtrosDetallesDos";

const DetallePaquete = () => {

    return(
        <div className="container">
            <div className="row">
                <div className="col">
                    <h1>detalle paquete</h1>
                    <div className="paquete my-5">< PaqueteMR/></div>
                   <div className="Detalle my-5"> < Detalle/> </div>
                    <Itinerario/>
                    <OtrosDetalle/>
                    <OtrosDetallesDos/>
                    
                </div>
            </div>
        </div>
    );
};
export default DetallePaquete;