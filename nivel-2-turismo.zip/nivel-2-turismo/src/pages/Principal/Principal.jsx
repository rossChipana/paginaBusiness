import Carrusel from "./Carrusel";
import DestinosPopulares from "./DestinosPopulares";
import Footer from "./Footer";
import Formulario from "./Formulario";
import Testimonios from "./Testimonios";


const Principal = () => {
    return(
        <div className="container">
            <div className="row">
                <div className="col">
                    <h1>principal</h1>
                    <Carrusel/>

                    < div className="row">
                       
                    <DestinosPopulares/>
                    <DestinosPopulares/>
                    <DestinosPopulares/>

                    
                    </div>
                    <Formulario/>
                    <Testimonios/>
                    <Footer/>
                    
                       </div>
                    </div>
                </div>
            
    );
};
export default Principal;