const DestinosPopulares = () => {
    return(
        

<div className="card" style={{ width: "18rem" }}>
  <img src="/src/assets/images/CancunMexico.png" className="card-img-top" alt="..."/>
  <div className="card-body">
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the content.</p>
  </div>
</div>
);
};

export default DestinosPopulares;