const Formulario = () => {
    return(

        <form className="row g-3">
  <div className="col-md-6">
    <label htmlFor="inputEmail4" className="form-label" >Email</label>
    <input type="email" className="form-control"  placeholder="Nombre"/>
  </div>


  <div className="col-md-6">
    <label htmlFor="inputPassword4" className="form-label">Password</label>
    <input type="password" className="form-control" id="inputPassword4" placeholder="Email"/>
  </div>
  <div className="col-md-6">
    <label htmlFor="inputEmail4" className="form-label" >Email</label>
    <input type="email" className="form-control"  placeholder="Nombre"/>
  </div>
  <div className="col-md-6">
    <label htmlFor="inputEmail4" className="form-label" >Email</label>
    <input type="email" className="form-control" id="inputEmail4" placeholder="Nombre"/>
  </div>
  <div className="form-floating">
  <textarea className="form-control" placeholder="Leave a comment here"  style={{height: '100px'}}></textarea>
  <label htmlFor="floatingTextarea2">Comments</label>
</div>
  </form>
        );
    };
    export default Formulario;
    